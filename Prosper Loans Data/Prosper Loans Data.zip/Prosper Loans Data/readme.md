# (Dataset Exploration Title)
## by (your name here)


## Dataset

> Prosper Loans Data: This data set contains 113,937 loans with 81 variables on each loan, including loan amount, borrower rate (or interest rate), current loan status, borrower income, and many others.


## Summary of Findings

> more than 80% of loans are current or completed with around 50% being chargedoff and defaulted and about 10% of loans are past due. 
> Most borrowers have a propser score of around 4.0 and most borrowers are between 2.0 and 10.0
> The top borrowers are administrative assistants followed by bus driver.
> The most popular loan category is the debt consolidated.
> Most borrowers don't have Delinquencies.
> The correlation between the matrixes shows that ProsperScore seems to be more related to BorrowerAPR and people with a higher rating of ProsperScore have a low borrowrAPR.
> Borrowers with high prosper score completed their loan


## Key Insights for Presentation

> I used histogram plots to visualize the Loan status, borrowers APR, credit range and borrowers occupation to get insights on the dataset. After exploring several attributes of the dataset I found that Borrowers APR and Prosper score had the strongest relationship, I also implemented a scatter and heat map plot which showed that ProsperScore and BorrowerAPR were negatively correlated. In addition in order to check to loan statuses a box plot helped to gain insight and show that borrowers with high prosper score completed their loan Payment. Further insights show most borrowers were administrative assistants.